#include "application.h"
#include "main.h"
#include "board.h"
#include "maintimer.h"
#include "board.h"
#include "iwdg.h"
#include "usbd_core.h"
#include "usb_device.h"
#include "usbd_dfu.h"
#include "usbd_dfu_if.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>



// Indirizzo e valore richiesta upgrade (che pu� effettuare l'applicazione)
#define ADDR_REQUEST_UPGRADE		0x2001FFF0
#define VAL_REQUEST_UPGRADE			0xA8AD5CEF



pFunction JumpToApplication;
uint32_t JumpAddress;


static uint8_t watchdogReset = FALSE;


// Metodi interni
void Application_Poll(void);


// Contiene l'istante in cui � iniziato il ciclo main corrente
static uint16_t startCiclo = 0;


static uint16_t contRun = 0;







void MainTimer_Callback(void)
{
#define TIME_FLASH_LED		1000

	static uint16_t contMs = 0;

	if (++contMs > (TIME_FLASH_LED * 5))
		contMs = TIME_FLASH_LED;

	// Gestione lampeggio alternato dei 4 led
	if (contMs >= (TIME_FLASH_LED * 4))
	{
		LED_PC1_Off;
		LED_PC2_On;
	}
	else if (contMs >= (TIME_FLASH_LED * 3))
	{
		LED_ON_Off;
		LED_PC1_On;
	}
	else if (contMs >= (TIME_FLASH_LED * 2))
	{
		LED_ERR_Off;
		LED_ON_On;
	}
	else if (contMs >= TIME_FLASH_LED)
	{
		LED_ERR_On;
		LED_PC2_Off;
	}
}



/** Verifica se � il caso di saltare al codice applicazione */
void CheckApplic(void)
{
	uint32_t boot;

	// Se non c'� stato un reset x watchdog
	if (watchdogReset == FALSE)
	{
		boot = *((uint32_t*)ADDR_REQUEST_UPGRADE);

		// Nessuna richiesta di aggiornamento?
		if (boot != VAL_REQUEST_UPGRADE)
		{
			// Test if user code is programmed starting from address ADDRESS_APPLIC
			if (((*(__IO uint32_t*)ADDRESS_APPLIC) & 0x2FFE0000 ) == 0x20000000)
			{
				// Jump to user application
				JumpAddress = *(__IO uint32_t*) (ADDRESS_APPLIC + 4);
				JumpToApplication = (pFunction) JumpAddress;

				// Abilita watchdog prima di lanciare l'applicazione
				MX_IWDG_Init();
				HAL_IWDG_Refresh(&hiwdg);

				// Initialize user application's Stack Pointer
				__set_MSP(*(__IO uint32_t*) ADDRESS_APPLIC);
				JumpToApplication();
			}

		}

		// Elimina la richiesta di aggiornamento
		*((uint32_t*)ADDR_REQUEST_UPGRADE) = 0;
	}

}





/*
static void SetCode(void)
{
	uint32_t codeL, codeH;
	uint32_t buf[3];
	char str[14];

	if ( (*((uint32_t*)ADDR_CODE_H) == 0xffffffff) && (*((uint32_t*)ADDR_CODE_L) == 0xffffffff) )
	{
		// Carica nel buffer l'ID del micro su 96 bit
		HAL_GetUID(buf);

		// Calcola CRC sui primi 32 bit dell'ID (polinomio = 0x4C11DB7)
		codeL = HAL_CRC_Calculate(&hcrc, buf, 1);
		// Calcola CRC sull'intero ID
		codeH = HAL_CRC_Calculate(&hcrc, buf, 3);

		HAL_FLASH_Unlock();
		HAL_FLASH_Program(TYPEPROGRAM_WORD, (uint32_t)(ADDR_CODE_H), codeH);
		HAL_FLASH_Program(TYPEPROGRAM_WORD, (uint32_t)(ADDR_CODE_L), codeL);

		// Scrive a partire dall'indirizzo ADDR_BOOT_VERSION la versione del bootloader
		// (utilizzando i seguenti metodi, verr� memorizzata come 00WF.BA0 100 anzich� FW000AB.001. Mantenuto questa logica in quanto la stessa che verr� utilizzata per la rilettura)
		sprintf(str, "%s.%s", APP_NAME, APP_VERSION);
		for (int w=0; w<strlen(str); w++)
			HAL_FLASH_Program(TYPEPROGRAM_BYTE, (uint32_t)(ADDR_BOOT_VERSION + w), str[w]);

		HAL_FLASH_Lock();
	}

}
*/



void Application_Run(void)
{
	// Verifica se c'� stato un Reset x Watchdog ?
	if (RCC->CSR & (RCC_CSR_IWDGRSTF) )
	{
		RCC->CSR |= RCC_CSR_RMVF;
		watchdogReset = TRUE;
	}

	// Attesa iniziale
	startCiclo = MainTimer_GetValue();
	while ((MainTimer_GetValue() - startCiclo) < 100);

	// Imposta codice di sicurezza
//	SetCode();

	// Verifico se � presente una richiesta di aggiornamento
	CheckApplic();

	while (1)
	{	
		// Memorizza istante inizio ciclo main
		startCiclo = MainTimer_GetValue();

		// Se da 60 secondi non ricevo file
		if (++contRun > (60000 / TIME_MAIN_CYCLE))
		{
			// Azzera flag reset per watchdog
			watchdogReset = FALSE;

			CheckApplic();
		}

		// Attesa ciclo
		while ((MainTimer_GetValue() - startCiclo) < TIME_MAIN_CYCLE);
	}
 
}


/** Richiamata quando si sta ricevendo il firmware applicazione da USB */
void Downloading(void)
{
	contRun = 0;
}







