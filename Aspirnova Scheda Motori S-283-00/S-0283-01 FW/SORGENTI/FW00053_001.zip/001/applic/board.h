/**	\file   board.h
 * 
 * 	\brief  Board configuration
 * 
 * 	\author Walter Giusiano - lab3841 srl \n
 *  walter.giusiano@lab3841.it
 *
 *  \version    v1.0 - 11/06/2018
 * 	-   Versione iniziale
 *
 *
 *  \section req Requirements
 *
 */ 
#include "stm32f2xx_hal.h"
#include "stm32f2xx_hal_gpio.h"
#include <stdlib.h>
#include <stdio.h>

#ifndef _BOARD_H_
#define _BOARD_H_

// Boolean
#define TRUE				1
#define FALSE				0

// Result
#define RESULT_OK			0
#define RESULT_ERR			1


// Indirizzi
#define ADDRESS_APPLIC            	0x08008000	// Il primo settore (16 KB) � riservato al bootloader
//#define ADDR_BOOT_VERSION			(ADDRESS_APPLIC - 64)
//#define ADDR_CODE_H				(ADDRESS_APPLIC - 16)
//#define ADDR_CODE_L				(ADDRESS_APPLIC - 32)

// Indirizzo e valore richiesta upgrade (da richiedere al bootloader)
#define ADDR_REQUEST_UPGRADE		0x2001FFF0
#define VAL_REQUEST_UPGRADE			0xA8AD5CEF





// LED ERR
#define LED_ERR_On				LED_ERR_GPIO_Port->BSRR = (uint32_t)LED_ERR_Pin << 16U;	//HAL_GPIO_WritePin	(LED_ERR_GPIO_Port, LED_ERR_Pin, GPIO_PIN_RESET)
#define LED_ERR_Off				LED_ERR_GPIO_Port->BSRR = LED_ERR_Pin;	//HAL_GPIO_WritePin	(LED_ERR_GPIO_Port, LED_ERR_Pin, GPIO_PIN_SET)


// LED ON
#define LED_ON_On				LED_ON_GPIO_Port->BSRR = (uint32_t)LED_ON_Pin << 16U;	//HAL_GPIO_WritePin	(LED_ON_GPIO_Port, LED_ON_Pin, GPIO_PIN_RESET)
#define LED_ON_Off				LED_ON_GPIO_Port->BSRR = LED_ON_Pin;	//HAL_GPIO_WritePin	(LED_ON_GPIO_Port, LED_ON_Pin, GPIO_PIN_SET)

// LED PC1
#define LED_PC1_On				LED_PC1_GPIO_Port->BSRR = (uint32_t)LED_PC1_Pin << 16U;	//HAL_GPIO_WritePin	(LED_PC1_GPIO_Port, LED_PC1_Pin, GPIO_PIN_RESET)
#define LED_PC1_Off				LED_PC1_GPIO_Port->BSRR = LED_PC1_Pin;	//HAL_GPIO_WritePin	(LED_PC1_GPIO_Port, LED_PC1_Pin, GPIO_PIN_SET)

// LED PC2
#define LED_PC2_On				LED_PC2_GPIO_Port->BSRR = (uint32_t)LED_PC2_Pin << 16U;	//HAL_GPIO_WritePin	(LED_PC2_GPIO_Port, LED_PC2_Pin, GPIO_PIN_RESET)
#define LED_PC2_Off				LED_PC2_GPIO_Port->BSRR = LED_PC2_Pin; 	//HAL_GPIO_WritePin	(LED_PC2_GPIO_Port, LED_PC2_Pin, GPIO_PIN_SET)


/*************************** SERIAL NUMBER ************************************/
typedef struct
{
  uint32_t L;
  uint32_t H;
} UDID_TypeDef;

#define UDID_BASE			0x1FFF7A10
#define UDID               ((UDID_TypeDef *) UDID_BASE)

// Recupera ID micro
//sprintf(keygen, "%08x%08x", UDID->H, UDID->L);





#endif


