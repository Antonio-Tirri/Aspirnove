/**	\mainpage FW00053 - ASPIRNOVA Bootloader Scheda Controllo
 *
 * 	\author Walter Giusiano - lab3841 srl \n
 *  walter.giusiano@lab3841.it
 *
 *
 *  \version \b FW00053.001 - 21/03/2019
 *  - Versione iniziale
 *
 *
 *
 * <b>Funzionamento</b>\n
 *	Dopo ogni reset del micro viene eseguito il bootloader. \n
 *
 *	Il bootloader lancia l'applicazione oppure tenta di aggiornare il firmware in uno dei seguenti casi:
 *		* richiesta dell'applicazione (all'indirizzo in ram ADDR_REQUEST_UPGRADE e' presente il valore VAL_REQUEST_UPGRADE),
 *		* nessun firmware applicazione presente
 *		* l'ultimo reset del micro � stato forzato dal watchdog
 *
 *
 *	Nel caso si tenti l'aggiornamento, il bootloader rimane in attesa di ricevere un nuovo firmware applicazione dall'USB. \n
 *	(Il bootloader attende al massimo 60 secondi per ricevere il file dopodich� invalida la richiesta di aggiornamento e salta all'applicazione.)
 *
 *	Quando il bootloader e' in esecuzione i led si accendono ciclicamente con la seguente sequenza: \n
 *		* LED_ERR per un secondo
 *		* LED_ON per un secondo
 *		* LED_PC1 per un secondo
 *		* LED_PC2 per un secondo
 *
 *	Per comunicare con la scheda utilizzare l'applicazione ST DfuSeDemo. \n
 *
 *
 *
 *
 *  \page Dettagli Dettagli
 *
 * 	<b>Micro</b>\n
 *		- STM32F205RB
 *
 * 	<b>Compilatore utilizzato</b>\n
 *		- TrueSTUDIO for STM32 v9.0.0
 *
 * 	<b>Hardware compatibile</b>\n
 *		LB00103
 * 
 *	<b>Memoria: </b>\n
 *
 *	<table>
 *	<caption id="multi_row">MICRO</caption>
 *	<tr><th>Settore</th>	<th>Indirizzo</th>	<th>Dimensione</th>	<th>Utilizzo</th>
 *	<tr> <td>0</td>	<td>0x8000000</td>	<td>16K</td> 	<td>Firmware Bootloader</td></tr>
 *	<tr> <td>1</td>	<td>0x8004000</td>	<td>16K</td>		<td>Parametri Applic</td> </tr>
 *	<tr> <td>2</td>	<td>0x8008000</td>	<td>16K</td>		<td>Firmware Applic</td> </tr>
 *	<tr> <td>3</td>	<td>0x800C000</td>	<td>16K</td>	<td>Firmware Applic</td> </tr>
 *	<tr> <td>4</td>	<td>0x8010000</td>	<td>64K</td>		<td>Firmware Applic</td> </tr>
 *	</table>
 *	<br>
 *
 *	<br><br>
 *
 *
 *	<b>Compatibilita' con l'applicazione: </b>\n
 *		- Indirizzo partenza Codice BOOTLOADER: 		= 0x8000000
 *		- Indirizzo partenza Codice APPLICAZIONE:		= 0x8008000
 *
 * 	<b>Note</b>\n
 *  - Ottimizzazione impostata a "Optimize (-O1)" per riuscire a far stare il bootloader nei 16K del primo settore.
 *  - Le funzioni di cancellazione flash, scrittura flash, verifica indirizzi si trovano nel file usbd_dfu_if.c
 *  - Prima di caricare il bootloader effettuare un erase completa del micro (per ripulire le aree ADDR_BOOT_VERSION_x e ADDR_CODE_x).
 *
 *
 *	<b>Rilascio versione</b>\n
 *	- Generare la documentazione del progetto, lanciando il file batch doc\genera_doc.bat
 *
 */

#include <stdint.h>

// Application info
#define APP_NAME		"FW00053"
#define APP_VERSION		"001"
#define APP_BUILD		"(Build: " __DATE__ " - " __TIME__ ")"
#define APP_COMPANY		"lab3841"
#define APP_AUTHOR		"W.Giusiano"
#define APP_HARDWARE	"LB00103"


// Time main cycle, in ms
#define TIME_MAIN_CYCLE		10


/** Gestione applicazione. */
void Application_Run(void);



