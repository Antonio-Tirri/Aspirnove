var indexSectionsWithContent =
{
  0: "bdfu",
  1: "u",
  2: "b",
  3: "df"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Pagine"
};

