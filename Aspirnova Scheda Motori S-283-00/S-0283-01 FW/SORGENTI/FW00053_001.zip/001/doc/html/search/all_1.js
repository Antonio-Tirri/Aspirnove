var searchData=
[
  ['dettagli',['Dettagli',['../_dettagli.html',1,'']]]
];
