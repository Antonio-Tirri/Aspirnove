var searchData=
[
  ['tdate',['tDate',['../dati_8h.html#a684ca968c266256d65fa7ff7999c412f',1,'dati.h']]],
  ['tdatetime',['tDateTime',['../dati_8h.html#aec2a4997f1eff276d0fc6330e90cebf3',1,'dati.h']]],
  ['tparameters',['tParameters',['../dati_8h.html#a14e9b47820c1a85ade7aa1f9d8ea7eca',1,'dati.h']]],
  ['ttime',['tTime',['../dati_8h.html#a5a5e18dd6631dd7ccd798bdca2de9f95',1,'dati.h']]]
];
