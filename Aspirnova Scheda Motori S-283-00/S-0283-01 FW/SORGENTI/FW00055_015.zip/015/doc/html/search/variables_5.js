var searchData=
[
  ['temperature',['Temperature',['../struct__t_n_t_c_curve.html#ace6ad735170c62486bc00e5424f9647f',1,'_tNTCCurve']]]
];
