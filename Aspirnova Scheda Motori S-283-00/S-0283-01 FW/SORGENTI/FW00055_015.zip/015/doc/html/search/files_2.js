var searchData=
[
  ['dati_2eh',['dati.h',['../dati_8h.html',1,'']]],
  ['debug_2eh',['debug.h',['../debug_8h.html',1,'']]]
];
