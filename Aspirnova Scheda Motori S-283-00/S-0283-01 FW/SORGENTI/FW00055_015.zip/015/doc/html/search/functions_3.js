var searchData=
[
  ['dati_5finit',['Dati_Init',['../dati_8h.html#adf03bdb23d682af7a0bd09afc415d750',1,'dati.c']]],
  ['dati_5fload',['Dati_Load',['../dati_8h.html#a6a471406e0c8eb70cf5263dd1c4e0832',1,'dati.c']]],
  ['dati_5floaddefaultparameters',['Dati_LoadDefaultParameters',['../dati_8h.html#a414f1579187bbd7d07463a334c179ef7',1,'dati.c']]],
  ['dati_5fsave',['Dati_Save',['../dati_8h.html#ad96ca670459e0d1586697f45da2c6415',1,'dati.c']]],
  ['dati_5fstatussave',['Dati_StatusSave',['../dati_8h.html#a017d3e86cff2162e32fdf63950b65673',1,'dati.c']]],
  ['debug',['Debug',['../debug_8h.html#a11980e6c14122e906d99bd57bd04ce6c',1,'debug.c']]],
  ['debug_5fgettxlen',['Debug_GetTxLen',['../debug_8h.html#a2884a538aece35c34996bea5243b4d4e',1,'debug.c']]],
  ['debug_5fsetlevel',['Debug_SetLevel',['../debug_8h.html#a47c3ba4b074f00cede7aeac0f6caca89',1,'debug.c']]]
];
