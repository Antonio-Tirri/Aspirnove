var searchData=
[
  ['data',['data',['../struct__t_data_table.html#a35289d16823a7671de414f4c4f75c895',1,'_tDataTable']]],
  ['day',['Day',['../struct____packed.html#a0d091a3ff75de51534dfa148b3955dcb',1,'__packed']]]
];
