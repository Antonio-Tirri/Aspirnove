var indexSectionsWithContent =
{
  0: "_abcdfghimpstuy",
  1: "_",
  2: "abdhimptu",
  3: "abcdfgimpsu",
  4: "cdhmsty",
  5: "t",
  6: "d",
  7: "c",
  8: "df"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Ridefinizioni di tipo (typedef)",
  6: "Valori del tipo enumerato",
  7: "Definizioni",
  8: "Pagine"
};

