var searchData=
[
  ['sec',['Sec',['../struct____packed.html#abea2592eea80ac81fd2ffe26580db19d',1,'__packed']]],
  ['size',['size',['../struct__t_data_table.html#ae5895c19e781dd6c016e5aa233159436',1,'_tDataTable']]]
];
